setwd("C:\\Users\\it24102872\\Desktop\\IT24102872")
getwd()
# Importing the data
data <- read.table("Data.txt", header=TRUE, sep = ",")
attach(data)

# Part 1
# Rename the variables (column headings) of the data set as x1 and x2
names(data) <- c("x1", "x2")
attach(data)
hist(x2, main="Histogram for Number of Shareholders")

# Part 2
# Using breaks command we can define number of classes we need in the histogram
# lower.limit and upper.limit can define whether classes have closed intervals or open intervals.

# Using with lower.limit and upper.limit
hist(x2, main="Histogram for Number of Shareholders", breaks = seq(130, 270, length = 8), right = FALSE)

# Check how each argument inside "hist" command works using "help" command as follows
?hist


# Part 3
# Assign class limits of the frequency distribution into a variable called "breaks"
breaks <- round(histogram$breaks)
# Assign class frequencies of the histogram into a variable called "freq"
freq <- histogram$counts
# Assign mid point of each class into a variable called "mids"
mids <- histogram$mids
# Creating the variable called "Classes" for the frequency distribution
classes <- c()
# Creating a "for" loop to assign classes of the frequency distribution into "Classes" variable created above.
for(i in 1:length(breaks)-1) {
  classes[i] <- paste0("(", breaks[i], " , ", breaks[i+1], ")")
}
# Obtaining frequency distribution by combining the values of "Classes" & "Freq" variables
# "cbind" command used to merge the columns with same length
cbind(Classes, Frequency = freq)


# Part 4
# Draw frequency polygon to the same plot.
lines(mids, freq)

# Draw frequency polygon in a new plot.
plot(mids, freq, type = "l", main = "Frequency Polygon for Shareholders", xlab = "Shareholders", ylab = "Frequency", ylim = c(0, max(freq)))

